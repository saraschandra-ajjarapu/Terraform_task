#
create vpc
create ec2 instance using ubuntu linux
enable and configure security group
server hardening 
    --> ssh on non standard port 
    --> disable password based sing in 
    --> configure UFW (ubuntu firewall)
    --> disable root access
VPN --> enable access only through openvpn to this instance
cloud watch --> setup cloudwatch for disk size and cpu
enable emails alerts for alerts 
enable clamav --> free antivirus for linux
enable backup for instance


    export AWS_ACCESS_KEY_ID='accesskey
    export AWS_SECRET_ACCESS_KEY=secret key

    10.0.0.0/24
    10.0.1.0/24
    10.0.2.0/23