#!/usr/bin/env python
import hcl
import os
import sys
#Python 2.7
path = os.getcwd()+"/variables/"+os.environ["FILE"]
path2 = os.getcwd()+"/variables/"+os.environ["FILE2"]

list1 =[]
list2 =[]

def arrayify( path, list ):
    with open(path, 'r') as fp:
        obj = hcl.load(fp)
        for key, value in obj.items():
            typeof = value.__class__.__name__
            inter = ""
            if typeof == "list":
                inter = " type = \"list\" "
            if typeof == "dict":
                inter = " type = \"map\" "
            list.append(key)

arrayify(path, list1)
arrayify(path2, list2)

err = 0
for value in list1:
    if value not in list2:
        print('\033[91m'+" Variable Mismatch: "+path2+" is missing "+'\033[1m'+value+'\033[0m')
        err = 1

for value in list2:
    if value not in list1:
        print('\033[91m'+" Variable Mismatch: "+path+" is missing "+'\033[1m'+value+'\033[0m')
        err = 1


if err > 0:
    sys.exit("fix please")
else:
    print(path+" & "+path2+" match, tests ok")
