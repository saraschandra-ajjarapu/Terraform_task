#!/usr/bin/env python
import hcl
import os
import logging

#Python 2.7
try:
    path = os.getcwd()+"/variables/"+os.environ["FILE"]
    with open(path, 'r') as fp:
        f = open("variables.tf", 'w')
        obj = hcl.load(fp)
        for key, value in obj.items():
            typeof = value.__class__.__name__
            inter = ""
            if typeof == "list":
                inter = " type = \"list\" "
            if typeof == "dict":
                inter = " type = \"map\" "
            f.write("variable "+key+" {"+inter+"}\n")
except Exception as z:
    logging.error(z)
