#scripts

## import_tfvars.py

## bootstrap/boot_init_*.py

This script contains all of the code necessary to bootstrap the environment for terraform to be able to run. The script creates the necessary S3 bucket to store terraform state.

`make bootstrap env=<yourenvhere>` will bootstrap the environment with the correct prefix.
